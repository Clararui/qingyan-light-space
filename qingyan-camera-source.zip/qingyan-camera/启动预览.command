#!/bin/zsh
set -eu

task_preview_root="${0:A:h}"
task_preview_node="$(command -v node || true)"
if [[ -z "$task_preview_node" ]]; then
  task_preview_node="$HOME/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node"
fi
if [[ ! -x "$task_preview_node" ]]; then
  printf '请安装 Node.js 20 或更高版本，再双击启动预览。\n'
  read -r '?按回车键结束。'
  exit 1
fi

cd "$task_preview_root"
"$task_preview_node" scripts/start-preview.mjs
open 'http://127.0.0.1:4173/#top'
printf '\n预览服务已在后台运行。电脑重启后，需要再次双击本文件。\n'
read -r '?按回车键关闭此窗口，网页服务会继续运行。'
