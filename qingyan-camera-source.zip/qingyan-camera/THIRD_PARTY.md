# Third-party dependencies

| Files | Version | License / source |
| --- | --- | --- |
| `vendor/three/` | Three.js 0.180.0 | MIT, included in `vendor/three/LICENSE`; https://github.com/mrdoob/three.js |
| `vendor/gsap.min.js`, `vendor/ScrollTrigger.min.js` | GSAP 3.13.0 | GSAP Standard No Charge License: https://gsap.com/community/standard-license/ |
| `vendor/qrcode.js` | qrcode-generator 1.4.4 | MIT, Copyright (c) 2009 Kazuhiko Arase, source: https://github.com/kazuhikoarase/qrcode-generator |

The original copyright and license header in each JavaScript library is retained. The MIT license for project-authored code does not relicense the third-party libraries or photography. See `ASSETS.md` for photograph sources.

Library files were obtained from jsDelivr's npm mirror, using the pinned versions above. They are bundled locally so the page does not require runtime third-party network requests.
