import { mkdir, readFile, writeFile, copyFile, readdir } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'qingyan-light-space-pages');
await mkdir(output, { recursive: true });

// Flat files can be uploaded together through GitHub's web UI. Relative imports
// and portrait paths are rewritten; the original source remains unchanged.
const replacePaths = text => text
  .replaceAll('./src/', './')
  .replaceAll('./vendor/three/', './')
  .replaceAll('./vendor/', './')
  .replaceAll('./assets/portraits/', './')
  .replaceAll('./assets/', './');
for (const file of ['index.html', 'src/app.js', 'src/scene.js', 'src/config.js', 'src/styles.css']) {
  const text = await readFile(path.join(root, file), 'utf8');
  await writeFile(path.join(output, path.basename(file)), replacePaths(text));
}
for (const file of [
  'assets/favicon.svg', 'vendor/three/three.module.min.js',
  'vendor/three/three.core.min.js', 'vendor/gsap.min.js',
  'vendor/ScrollTrigger.min.js', 'vendor/GSAP-LICENSE.txt',
  'LICENSE', 'ASSETS.md', 'qingyan-camera-source.zip',
]) await copyFile(path.join(root, file), path.join(output, path.basename(file)));
await copyFile(path.join(root, 'vendor/three/LICENSE'), path.join(output, 'THREE-LICENSE.txt'));
for (const file of await readdir(path.join(root, 'assets/portraits'))) {
  if (file.endsWith('.webp')) await copyFile(path.join(root, 'assets/portraits', file), path.join(output, file));
}
await writeFile(path.join(output, '.nojekyll'), '');
await writeFile(path.join(output, 'THIRD_PARTY.md'), `# Third-party dependencies\n\nThree.js 0.180.0: MIT, see THREE-LICENSE.txt.\nGSAP 3.13.0 / ScrollTrigger: GSAP Standard No Charge License, see GSAP-LICENSE.txt.\n\nOriginal library license headers are retained. Photography retains its Pexels license; see ASSETS.md. The project MIT license covers original code only.\n`);
await writeFile(path.join(output, 'README.md'), "# 轻颜相机 · 光，不止一面\n\n黑银色沉浸式 3D 单页网页：悬浮手机、螺旋画廊、快门飞片与品牌星环。\n\nGitHub Pages 地址：https://clararui.github.io/qingyan-light-space/\n\n本仓库提供可直接发布的静态文件，依赖与素材全部本地化。Pages 使用 main 分支的根目录发布；提交更新后自动重新部署。\n\n本地预览：在仓库目录运行 `python3 -m http.server 4173`，访问 http://127.0.0.1:4173/ 。请通过 HTTP 打开。\n\n原始完整工程、构建脚本和素材配置见 [qingyan-camera-source.zip](./qingyan-camera-source.zip)。原创代码遵循 MIT，第三方库和摄影分别遵循其原有许可。\n");
const html = await readFile(path.join(output, 'index.html'), 'utf8');
const config = await readFile(path.join(output, 'config.js'), 'utf8');
const local = [...`${html}\n${config}`.matchAll(/(?:src=|href=)?['"]\.\/([^'"\s]+)['"]/g)].map(match => match[1]);
for (const file of new Set(local)) await readFile(path.join(output, file));
console.log(`GitHub Pages 文件已准备：${output}（${(await readdir(output)).length} 个文件）`);
