import { cp, mkdir, readFile, readdir, rm } from 'node:fs/promises';
import path from 'node:path';
const output=path.resolve('dist');
await rm(output,{recursive:true,force:true});await mkdir(output,{recursive:true});
for(const name of ['index.html','src','assets','vendor','LICENSE','ASSETS.md','THIRD_PARTY.md'])await cp(name,path.join(output,name),{recursive:true});
// 构建时检查静态入口实际引用的图片，避免 GitHub Pages 出现缺图。
const html=await readFile('index.html','utf8');
const config=await readFile('src/config.js','utf8');
const local=[...`${html}\n${config}`.matchAll(/(?:src=|href=)?['"]\.\/(assets\/[^'"\s]+)['"]/g)].map(m=>m[1]);
for(const file of new Set(local))await readFile(file);
await readFile('vendor/three/three.module.min.js');await readFile('vendor/gsap.min.js');
console.log(`已生成 GitHub Pages 静态站点：dist/（检查 ${new Set(local).size} 个素材引用）`);
