import { spawn } from 'node:child_process';
import { mkdir, open, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const port = Number(process.env.PORT || 4173);
const address = `http://127.0.0.1:${port}/`;

async function isReady() {
  try {
    const response = await fetch(address, { signal: AbortSignal.timeout(1000) });
    const html = await response.text();
    return response.ok && html.includes('<title>轻颜相机');
  } catch {
    return false;
  }
}

if (await isReady()) {
  console.log(`预览已经运行：${address}`);
} else {
  await mkdir(path.join(root, '.qa'), { recursive: true });
  const log = await open(path.join(root, '.qa/preview.log'), 'a');
  const child = spawn(process.execPath, ['scripts/serve.mjs'], {
    cwd: root,
    detached: true,
    stdio: ['ignore', log.fd, log.fd],
    env: { ...process.env, PORT: String(port) },
  });
  await new Promise((resolve, reject) => {
    child.once('spawn', resolve);
    child.once('error', reject);
  });
  child.unref();
  await log.close();
  await writeFile(path.join(root, '.qa/preview-process.json'), JSON.stringify({ pid: child.pid, address }, null, 2));
  let ready = false;
  for (let attempt = 0; attempt < 20; attempt++) {
    if (await isReady()) { ready = true; break; }
    await new Promise(resolve => setTimeout(resolve, 200));
  }
  if (!ready) {
    console.error('预览未能启动，请检查 .qa/preview.log。');
    process.exitCode = 1;
  } else {
    console.log(`后台预览已启动：${address}`);
  }
}
