# 轻颜相机 · 光，不止一面

黑银色的单页影像作品。未来时尚人像、液态金属和虹彩玻璃构成四个连续的 3D 场景；全页只有品牌、短标语和交互提示。

采用本地 **Three.js 0.180.0 + GSAP 3.13.0 / ScrollTrigger**。依赖与摄影素材均已包含，无需安装依赖或请求 CDN。所有资源使用相对路径，可部署到 GitHub Pages 仓库目录。

## 运行

Node.js 20 或更高版本：

```sh
npm run dev
```

打开 `http://127.0.0.1:4173/`。关闭终端后需要继续预览时，运行 `npm run preview:background`；日志与进程信息保存在 `.qa/`。本地地址仅供当前电脑访问。请通过 HTTP 打开，直接双击 HTML 无法加载 ES Modules。

```sh
npm run check
npm run build
```

构建结果在 `dist/`。

macOS 用户也可在项目文件夹双击 `启动预览.command`，自动启动后台服务并打开浏览器。电脑重启或预览进程停止后，需要重新启动；只有完成公网部署，网址才不依赖本机服务。

## 四个场景

1. 悬浮手机：有倒角与厚度的金属机身、玻璃屏幕、背部三镜头、侧键，搭配银色雕塑、玻璃环与人像。
2. 螺旋画廊：桌面 28 张、移动端 16 张有厚度的照片，沿不同深度排列；鼠标悬停、触摸或编号控件可聚焦。
3. 快门空间：软闪光、光圈扩散、手机后坐，照片从屏幕飞出、翻转并悬停。连续拍摄最多保留 6 张；后续照片替换最早的一张。
4. 影像星环：人像沿轨道聚拢至品牌周围；「再来一次」回到开场并清空拍摄拼贴。

同一个 WebGL 场景与透视相机贯穿全页。自然滚动和页内锚点控制连续镜头；鼠标灯光直接改变物体高光。摄影棚环境贴图提供金属反射，桌面使用 HDR Bloom 与轻微深度模糊，移动端使用直接渲染降低开销。

支持键盘聚焦、触控、减少动态效果偏好和后台暂停。减少动态效果时取消开场、漂浮、飞片翻转与摄影闪光，滚动改为静态场景切换。WebGL 不可用时保留静态人像。

## 配置

在 `src/config.js` 中修改人像路径、标题与移动端/桌面画质。素材是预设摄影作品；快门是视觉演出，不访问摄像头，不上传照片，不提供产品美颜或下载流程。

## GitHub Pages

独立公开仓库：[Clararui/qingyan-light-space](https://github.com/Clararui/qingyan-light-space)。

发布地址：https://clararui.github.io/qingyan-light-space/

本次发布使用 **main 分支根目录**，网页文件已整理为可直接发布的静态结构。后续更新：

1. 修改 index.html、src/ 或 assets/，运行 `npm run check` 和 `npm run build`。
2. 运行 `node scripts/export-github-pages.mjs`，生成 qingyan-light-space-pages/。
3. 将该目录中的发布文件提交到公开仓库的 main 根目录，Pages 自动重新部署。
4. 等待 Actions 中的 pages build and deployment 成功后验证网址。

原始工程保留 `.github/workflows/pages.yml`，可供采用源码结构和 GitHub Actions 构建的独立部署使用。当前公开仓库采用直接发布方式。

摄影授权与来源见 `ASSETS.md`。原创代码使用 MIT License；第三方库各自遵循其许可，见 `THIRD_PARTY.md`。
