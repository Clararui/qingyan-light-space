# 黑银色轻颜网页 · GitHub Pages

仓库：https://github.com/Clararui/qingyan-light-space
发布地址：https://clararui.github.io/qingyan-light-space/

本版本采用独立公开仓库和 main 根目录发布。源码与发布目录相互独立，修改源码后需要重新导出并提交发布文件。

发布配置：GitHub Settings → Pages → Deploy from a branch → main → / (root)。

## 更新网页

1. 修改本工程的 index.html、src/ 或 assets/。
2. 运行 `npm run check` 和 `npm run build`。
3. 运行 `node scripts/export-github-pages.mjs`，生成 qingyan-light-space-pages/。
4. 将该目录中的发布文件提交到 qingyan-light-space 仓库 main 根目录。文件相对路径已自动改写，适用于 GitHub Pages 仓库域名。
5. 在 Actions 查看 pages build and deployment 的结果，等待成功后访问公网地址。

本版本使用独立仓库，不覆盖 MUSE 版本的 Clararui/qingyan 仓库。
